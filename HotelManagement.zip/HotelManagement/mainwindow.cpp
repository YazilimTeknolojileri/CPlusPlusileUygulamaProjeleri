#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "roomsdialog.h"
#include "extradialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonCheckin_clicked()   // Slot
{
    RoomsDialog* roomsDialog = new RoomsDialog(this);
    roomsDialog->setIsCheckinPressed(true);    
    auto ret = roomsDialog->exec();   // Dialog penceresi açılır  

    if (ret == QDialog::Accepted)
    {
        qDebug() << "ChecIn Ok tiklandi!";
    } else {
        qDebug() << "ChecIn Cancel tiklandi!";
    }

    roomsDialog->deleteLater();
}


void MainWindow::on_pushButtonCheckout_clicked()
{
    RoomsDialog* roomsDialog = new RoomsDialog(this);
    roomsDialog->setIsCheckinPressed(false);
    auto ret = roomsDialog->exec();    

    if (ret == QDialog::Accepted)
    {
        qDebug() << "Checkout Ok tiklandi!";
    } else {
        qDebug() << "Checkout Cancel tiklandi!";
    }

    roomsDialog->deleteLater();
}




void MainWindow::on_pushButtonExtra_clicked()
{
    ExtraDialog* extraDialog = new ExtraDialog(this);

    auto ret = extraDialog->exec();

    if (ret == QDialog::Accepted)
    {
        qDebug() << "Extra Ok tiklandi!";
    } else {
        qDebug() << "Extra Cancel tiklandi!";
    }

    extraDialog->deleteLater();
}

