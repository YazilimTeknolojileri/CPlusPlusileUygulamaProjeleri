#include "mainwindow.h"
#include "hotel.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    int result = a.exec();

    // Program sonlanmadan önce Hotel nesnesini sil
    delete Hotel::getInstantance();

    return result;
}
