#include "extradialog.h"
#include "ui_extradialog.h"
#include "hotel.h"
#include "room.h"
#include <QMessageBox>

ExtraDialog::ExtraDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ExtraDialog)
{
    ui->setupUi(this);
}

ExtraDialog::~ExtraDialog()
{
    delete ui;
}

void ExtraDialog::on_pushButtonOk_clicked()
{
    bool okAmount;
    int amount = ui->lineEditAmount->text().toInt(&okAmount);

    bool okRoomNo;
    int roomNo = ui->lineEditRoomNo->text().toInt(&okRoomNo);

    if (okRoomNo && okAmount) {
        // İlgili odayı bul ve odaya charge işlemini yap..
        Hotel* hotel = Hotel::getInstantance();
        Room* room = hotel->findRoom(roomNo);

        // Kullanıcı geçersiz bir oda no girdiyse birşey yapma
        if (room != nullptr) {
            if (!room->isRoomOccupied()) {
                QMessageBox::critical(nullptr, "Error", "No expense can be spent on an empty room!");
            }
            room->addExtraExpense(amount);
        }

        accept();
    } else {
        reject();
    }
}


void ExtraDialog::on_pushButtonCancel_clicked()
{
    reject();
}

